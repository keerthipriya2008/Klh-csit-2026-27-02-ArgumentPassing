
import tkinter as tk
from tkinter import ttk, messagebox
import subprocess
import threading
import queue
import signal
from pathlib import Path
from datetime import datetime

# Project paths
ROOT = Path(__file__).resolve().parent.parent
WATCHDOG = ROOT / "watchdog"
SERVICE = ROOT / "src" / "test_service"

process = None
events = queue.Queue()
restart_count = 0

# ---------------- GUI WINDOW ----------------

root = tk.Tk()
root.title("Linux Process Watchdog")
root.geometry("950x620")
root.minsize(760, 500)
root.configure(bg="#101827")

style = ttk.Style()
style.theme_use("clam")
style.configure(
    "Treeview",
    background="#1F2937",
    foreground="white",
    fieldbackground="#1F2937",
    rowheight=30
)
style.configure(
    "Treeview.Heading",
    background="#374151",
    foreground="white"
)

title = tk.Label(
    root,
    text="Linux Process Watchdog",
    font=("Arial", 24, "bold"),
    fg="white",
    bg="#101827"
)
title.pack(pady=(20, 5))

subtitle = tk.Label(
    root,
    text="Linux Process Monitoring and Auto-Restart System",
    font=("Arial", 11),
    fg="#9CA3AF",
    bg="#101827"
)
subtitle.pack(pady=(0, 18))

status_var = tk.StringVar(value="Monitoring stopped")
pid_var = tk.StringVar(value="Process PID: —")
restart_var = tk.StringVar(value="Restart attempts: 0")

status_label = tk.Label(
    root,
    textvariable=status_var,
    font=("Arial", 13, "bold"),
    fg="#60A5FA",
    bg="#1F2937",
    pady=12
)
status_label.pack(fill="x", padx=25, pady=5)

summary = tk.Frame(root, bg="#101827")
summary.pack(fill="x", padx=25, pady=8)

tk.Label(
    summary, textvariable=pid_var,
    font=("Arial", 11), fg="white", bg="#101827"
).pack(side="left", padx=10)

tk.Label(
    summary, textvariable=restart_var,
    font=("Arial", 11), fg="white", bg="#101827"
).pack(side="right", padx=10)

columns = ("time", "event", "details")
table = ttk.Treeview(
    root, columns=columns, show="headings", height=12
)

table.heading("time", text="Time")
table.heading("event", text="Event")
table.heading("details", text="Details")

table.column("time", width=100, anchor="center")
table.column("event", width=180, anchor="center")
table.column("details", width=580)

table.pack(fill="both", expand=True, padx=25, pady=12)


def add_log(event, details):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    table.insert(
        "", "end",
        values=(timestamp, event, details)
    )
    table.yview_moveto(1)

    # Save each event permanently
    log_file = ROOT / "logs" / "watchdog.log"

    try:
        with open(log_file, "a", encoding="utf-8") as file:
            file.write(f"{timestamp} | {event} | {details}\n")
    except OSError as error:
        print(f"Could not write log: {error}")


# ---------------- BACKGROUND OUTPUT ----------------

def read_output(proc):
    try:
        for line in proc.stdout:
            events.put(("output", line.strip()))
    except (OSError, ValueError):
        pass
    finally:
        events.put(("finished", proc))

# ---------------- START WATCHDOG ----------------

def start_monitoring():
    global process, restart_count

    if process is not None and process.poll() is None:
        return

    if not WATCHDOG.is_file() or not SERVICE.is_file():
        messagebox.showerror(
            "Missing executable",
            "Compile the C programs first.\n\n"
            "Run in the Ubuntu terminal:\n"
            "gcc -Wall -Wextra -std=c11 "
            "src/test_service.c -o src/test_service\n"
            "gcc -Wall -Wextra -std=c11 "
            "src/watchdog.c -o watchdog"
        )
        return

    restart_count = 0
    restart_var.set("Restart attempts: 0")
    pid_var.set("Process PID: starting...")
    status_var.set("Starting watchdog...")
    status_label.config(fg="#FBBF24")

    try:
        process = subprocess.Popen(
            [str(WATCHDOG), str(SERVICE)],
            cwd=str(ROOT),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            start_new_session=True
        )

        add_log("SYSTEM", "C watchdog started")

        threading.Thread(
            target=read_output,
            args=(process,),
            daemon=True
        ).start()

    except OSError as error:
        process = None
        status_var.set("Failed to start")
        status_label.config(fg="#F87171")
        messagebox.showerror("Start failed", str(error))

# ---------------- STOP WATCHDOG ----------------

def stop_monitoring():
    global process

    proc = process

    if proc is None or proc.poll() is not None:
        status_var.set("Monitoring stopped")
        status_label.config(fg="#9CA3AF")
        return

    status_var.set("Stopping safely...")
    status_label.config(fg="#FBBF24")

    try:
        # Ask the C watchdog to shut down and clean up its child.
        proc.send_signal(signal.SIGTERM)

        def wait_for_stop():
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()

            events.put(("stopped", proc))

        threading.Thread(
            target=wait_for_stop,
            daemon=True
        ).start()

    except OSError as error:
        add_log("ERROR", str(error))

# ---------------- PROCESS EVENTS ----------------

def process_events():
    global process, restart_count

    while True:
        try:
            kind, data = events.get_nowait()
        except queue.Empty:
            break

        if kind == "output":
            line = data

            if "Child started. PID:" in line:
                pid = line.rsplit("PID:", 1)[-1].strip()
                pid_var.set("Process PID: " + pid)
                status_var.set("Service running")
                status_label.config(fg="#4ADE80")
                add_log("PROCESS STARTED", "PID " + pid)

            elif "Restart " in line and " of " in line:
                try:
                    restart_count = int(
                        line.split("Restart ", 1)[1].split(" of ", 1)[0]
                    )
                except ValueError:
                    pass

                restart_var.set(
                    f"Restart attempts: {restart_count}"
                )
                status_var.set("Recovering service...")
                status_label.config(fg="#FBBF24")
                add_log("AUTO-RESTART", line)

            elif "Child killed by signal" in line:
                add_log("PROCESS TERMINATED", line)

            elif "Child exited with code" in line:
                add_log("PROCESS EXITED", line)

            elif "Maximum restarts reached" in line:
                status_var.set("Restart limit reached")
                status_label.config(fg="#F87171")
                add_log("LIMIT REACHED", line)

            elif "Monitoring stopped" in line:
                add_log("SYSTEM", line)

            elif "exec:" in line or "fork:" in line or "waitpid:" in line:
                add_log("ERROR", line)

            else:
                add_log("WATCHDOG", line)

        elif kind == "finished":
            if process is data:
                status_var.set("Watchdog exited")
                status_label.config(fg="#9CA3AF")
                pid_var.set("Process PID: —")
                add_log("SYSTEM", "Watchdog process exited")

        elif kind == "stopped":
            if process is data:
                process = None
                status_var.set("Monitoring stopped")
                status_label.config(fg="#9CA3AF")
                pid_var.set("Process PID: —")
                add_log("SYSTEM", "Watchdog stopped safely")

    root.after(150, process_events)

# ---------------- BUTTONS ----------------

buttons = tk.Frame(root, bg="#101827")
buttons.pack(pady=(0, 20))

tk.Button(
    buttons,
    text="Start Monitoring",
    command=start_monitoring,
    bg="#15803D",
    fg="white",
    font=("Arial", 11, "bold"),
    width=18,
    pady=9
).pack(side="left", padx=8)

tk.Button(
    buttons,
    text="Stop Monitoring",
    command=stop_monitoring,
    bg="#B91C1C",
    fg="white",
    font=("Arial", 11, "bold"),
    width=18,
    pady=9
).pack(side="left", padx=8)

def close_window():
    if process is not None and process.poll() is None:
        stop_monitoring()
        root.after(300, close_window)
    else:
        root.destroy()

root.protocol("WM_DELETE_WINDOW", close_window)

add_log("SYSTEM", "Dashboard initialized")
process_events()
root.mainloop()
