
# Linux Process Watchdog and Auto-Restart System

## 1. Project Overview
This project monitors a selected Linux process and automatically
restarts it when it terminates unexpectedly.

The watchdog engine is implemented in C using Linux process
management system calls. A Python Tkinter GUI provides a
dashboard for monitoring status, displaying events, and
starting or stopping the watchdog.

## 2. Objectives
- Monitor a selected process.
- Detect unexpected process termination.
- Restart the process automatically.
- Display process IDs and restart events.
- Maintain a timestamped event log.
- Provide a graphical user interface.

## 3. Technologies Used
- C programming
- Linux / Ubuntu / WSL
- GCC compiler
- Python 3
- Tkinter
- Git and GitHub

## 4. Project Structure
- src/watchdog.c - Watchdog engine
- src/test_service.c - Test application
- gui/dashboard.py - Graphical interface
- logs/watchdog.log - Event history
- tests/ - Test cases
- docs/ - Project documentation

## 5. Requirements
- Ubuntu Linux or Ubuntu through WSL
- GCC compiler
- Python 3
- Python Tkinter
- Git

## 6. Installation
Install the required tools:

    sudo apt update
    sudo apt install build-essential python3 python3-tk git -y

Navigate to the project directory:

    cd /mnt/d/OSSP/linux-process-watchdog

## 7. Compilation

    gcc -Wall -Wextra -std=c11 src/test_service.c -o src/test_service
    gcc -Wall -Wextra -std=c11 src/watchdog.c -o watchdog

## 8. Execution

    python3 gui/dashboard.py

Click Start Monitoring to launch the watchdog.
Click Stop Monitoring to stop monitoring safely.

## 9. Testing
1. Start the GUI and begin monitoring.
2. Confirm the service PID appears.
3. Terminate only the test service process.
4. Verify that the watchdog restarts the service.
5. Check the new PID and restart events.
6. Verify the saved log in logs/watchdog.log.

## 10. Operating System Concepts
- Process creation using fork()
- Program execution using exec()
- Process synchronization using waitpid()
- Signal handling
- Parent-child process relationships
- Process termination and recovery

## 11. Safety
The project uses a dedicated test service.
The watchdog has a limited restart count.
Test only on processes you own or are authorized to manage.

## 12. Team Contributions
Member 1: C watchdog engine and process management.
Member 2: GUI development, testing, documentation, and presentation.

Update these roles to reflect actual contributions.
