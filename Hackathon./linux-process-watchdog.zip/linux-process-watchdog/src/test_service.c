#include <stdio.h>
#include <unistd.h>

int main(void)
{
    int count = 1;

    setvbuf(stdout, NULL, _IONBF, 0);

    printf("[SERVICE] Started. PID: %d\n", getpid());

    while (1)
    {
        printf("[SERVICE] Heartbeat %d\n", count++);
        sleep(2);
    }

    return 0;
}
