
#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>

#define MAX_RESTARTS 5
#define RESTART_DELAY 2

static volatile sig_atomic_t stopping = 0;
static pid_t child = -1;

static void handle_signal(int sig)
{
    (void)sig;
    stopping = 1;
}

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s ./src/test_service\n", argv[0]);
        return 1;
    }

    setvbuf(stdout, NULL, _IONBF, 0);

    struct sigaction sa = {0};
    sa.sa_handler = handle_signal;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);

    int restarts = 0;

    printf("[WATCHDOG] Monitoring started.\n");

    while (!stopping)
    {
        child = fork();

        if (child < 0)
        {
            perror("fork");
            return 1;
        }

        if (child == 0)
        {
            execl(argv[1], argv[1], (char *)NULL);
            perror("exec");
            _exit(127);
        }

        printf("[WATCHDOG] Child started. PID: %d\n", child);

        int status;
        pid_t result;

        do
        {
            result = waitpid(child, &status, 0);
        }
        while (result < 0 && errno == EINTR && !stopping);

        if (result < 0)
        {
            if (stopping)
                break;

            perror("waitpid");
            return 1;
        }

        child = -1;

        if (stopping)
            break;
if (WIFSIGNALED(status)) {
    printf("[WATCHDOG] SERVICE FAILED: terminated by signal %d\n",
           WTERMSIG(status));
} else if (WIFEXITED(status)) {
    printf("[WATCHDOG] SERVICE STOPPED: exit code %d\n",
           WEXITSTATUS(status));
}
        if (restarts >= MAX_RESTARTS)
        {
            printf("[WATCHDOG] Maximum restarts reached. Stopping.\n");
            break;
        }

        restarts++;

        printf("[WATCHDOG] Restart %d of %d in %d seconds.\n",
               restarts, MAX_RESTARTS, RESTART_DELAY);

        for (int i = 0; i < RESTART_DELAY && !stopping; i++)
            sleep(1);
    }

    if (child > 0)
    {
        pid_t old_child = child;

        if (kill(old_child, SIGTERM) == 0 || errno == EPERM)
        {
            while (waitpid(old_child, NULL, 0) < 0 && errno == EINTR)
            {
            }
        }
    }

    printf("[WATCHDOG] Monitoring stopped.\n");
    return 0;
}